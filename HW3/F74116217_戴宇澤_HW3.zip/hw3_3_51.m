num_a = [1 -2];
den_a = [1 2 10];
zeros_a = roots(num_a)
poles_a = roots(den_a)

num_b = [1 2 5];
den_b = [1 4 13 0];
zeros_b = roots(num_b)
poles_b = roots(den_b)

num_c = [1 10 5];
den_c = [1 4 10 6];
zeros_c = roots(num_c)
poles_c = roots(den_c)