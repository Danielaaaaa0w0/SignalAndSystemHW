b = [1 6 10]; %分子
a = [1 7 11 5]; %分母
[r,p,k] = residue(b,a)