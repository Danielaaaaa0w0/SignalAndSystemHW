x = [1 -1 2 4];
y = [2 6 4 0 8 5 12];
disp(deconv(y, x));