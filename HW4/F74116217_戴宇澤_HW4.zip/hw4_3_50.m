den = [1 -2 0 5 -1 4];
r = roots(den);
disp(r)