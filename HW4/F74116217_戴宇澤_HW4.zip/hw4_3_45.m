syms z n
X = z / (z - 0.6);
x_n = iztrans(X, z, n);
disp(x_n)